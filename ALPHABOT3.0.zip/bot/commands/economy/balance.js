const balances = {};

module.exports = {
  name: 'balance',
  description: 'Mostra il tuo saldo',
  execute(message) {
    const userId = message.author.id;
    const balance = balances[userId] || 0;
    message.channel.send(`${message.author.username}, il tuo saldo è 💰 ${balance}`);
  }
};