module.exports = {
  name: 'giveaway',
  description: 'Simula un giveaway semplice',
  execute(message) {
    message.channel.send('🎉 Giveaway iniziato! Usa !join per partecipare!');
  }
};