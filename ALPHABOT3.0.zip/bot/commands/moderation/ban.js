module.exports = {
  name: 'ban',
  description: 'Banna un utente',
  async execute(message, args) {
    if (!message.member.permissions.has('BanMembers')) return message.reply('Non hai i permessi.');
    const member = message.mentions.members.first();
    if (!member) return message.reply('Menziona un utente da bannare.');
    await member.ban();
    message.channel.send(`${member.user.tag} è stato bannato.`);
  }
};