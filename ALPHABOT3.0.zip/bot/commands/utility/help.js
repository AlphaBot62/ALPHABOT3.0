module.exports = {
  name: 'help',
  description: 'Mostra i comandi disponibili',
  execute(message) {
    message.channel.send('Comandi: !ban, !balance, !help');
  }
};