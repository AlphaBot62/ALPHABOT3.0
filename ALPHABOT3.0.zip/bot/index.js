require('dotenv').config();
const fs = require('fs');
const { Client, GatewayIntentBits, Collection } = require('discord.js');

const client = new Client({ intents: [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildMessages,
  GatewayIntentBits.MessageContent,
  GatewayIntentBits.GuildMembers
] });

client.commands = new Collection();
const commandFolders = fs.readdirSync('./bot/commands');

for (const folder of commandFolders) {
  const commandFiles = fs.readdirSync(`./bot/commands/${folder}`).filter(file => file.endsWith('.js'));
  for (const file of commandFiles) {
    const command = require(`./commands/${folder}/${file}`);
    client.commands.set(command.name, command);
  }
}

client.on('messageCreate', message => {
  if (!message.content.startsWith('!') || message.author.bot) return;
  const args = message.content.slice(1).split(/ +/);
  const command = args.shift().toLowerCase();

  if (client.commands.has(command)) {
    client.commands.get(command).execute(message, args);
  }
});

client.once('ready', () => {
  console.log(`🤖 ALPHABOT 3.0 pronto come ${client.user.tag}`);
});

client.login(process.env.TOKEN);